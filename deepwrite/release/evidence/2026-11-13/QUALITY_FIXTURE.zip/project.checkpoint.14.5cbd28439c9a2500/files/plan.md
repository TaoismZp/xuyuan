# Engineering fixture

Compare calculation errors against actual prose.
