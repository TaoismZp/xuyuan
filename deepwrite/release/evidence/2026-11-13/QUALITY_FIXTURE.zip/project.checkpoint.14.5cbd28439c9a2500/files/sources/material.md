Public engineering fixture only: two pairs contain four objects.
