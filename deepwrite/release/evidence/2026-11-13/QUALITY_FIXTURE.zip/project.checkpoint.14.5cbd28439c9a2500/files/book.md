# Engineering fixture

> 候选汇编（未获独立编辑/作者终校签收）。编排派生稿，不修改原稿。

## 目录

- 序言
- 第01章｜Arithmetic
- 尾声

---

# Preface

This is an engineering fixture, not a book experiment.

---


## 第01章｜Arithmetic

A calculation gives 2 + 2 = 4, verified by counting two pairs.

A reader needs a justified decision.

---

# Afterword

No human or independent quality review has occurred.
