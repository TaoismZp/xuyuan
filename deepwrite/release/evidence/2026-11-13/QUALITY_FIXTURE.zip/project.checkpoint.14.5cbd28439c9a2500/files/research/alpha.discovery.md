# Native source reasoning fixture

Two actors each bring two objects. Count both pairs to establish four before transferring the method.
