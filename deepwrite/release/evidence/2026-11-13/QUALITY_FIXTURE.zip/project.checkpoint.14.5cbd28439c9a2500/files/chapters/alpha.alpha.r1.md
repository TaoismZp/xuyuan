# Arithmetic fixture

A calculation gives 2 + 2 = 4, verified by counting two pairs.

A reader needs a justified decision.
