# Arithmetic fixture

A calculation claims 2 + 2 = 5. ERROR

A reader needs a justified decision.
